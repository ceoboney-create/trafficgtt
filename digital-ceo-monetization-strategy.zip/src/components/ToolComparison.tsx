import { useState, useEffect, useRef } from 'react';
import { ArrowRight, X, Check, Skull, Shield } from 'lucide-react';
import { cn } from '../utils/cn';

interface ToolRow {
  function_name: string;
  guru: string;
  guruCost: string;
  sovereign: string;
  sovereignCost: string;
}

const tools: ToolRow[] = [
  { function_name: 'Sales Funnel', guru: 'ClickFunnels', guruCost: '$147/mo', sovereign: 'Payhip', sovereignCost: '$0/mo' },
  { function_name: 'Email Marketing', guru: 'ConvertKit', guruCost: '$49/mo', sovereign: 'LeadsLeap', sovereignCost: '$0/mo' },
  { function_name: 'Automation', guru: 'Zapier', guruCost: '$49/mo', sovereign: 'n8n (self-hosted)', sovereignCost: '$0/mo' },
  { function_name: 'Course Hosting', guru: 'Kajabi', guruCost: '$149/mo', sovereign: 'Payhip + Own Domain', sovereignCost: '$0/mo' },
  { function_name: 'Link-in-Bio', guru: 'Linktree Pro', guruCost: '$9/mo', sovereign: 'Custom Landing', sovereignCost: '$0/mo' },
  { function_name: 'Analytics', guru: 'Premium SaaS', guruCost: '$29/mo', sovereign: 'GSC + Plausible', sovereignCost: '$0/mo' },
];

function AnimatedCounter({ end, prefix = '$', suffix = '' }: { end: number; prefix?: string; suffix?: string }) {
  const [value, setValue] = useState(0);
  const [started, setStarted] = useState(false);
  const ref = useRef<HTMLSpanElement>(null);

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting && !started) {
          setStarted(true);
          observer.disconnect();
        }
      },
      { threshold: 0.5 }
    );
    if (ref.current) observer.observe(ref.current);
    return () => observer.disconnect();
  }, [started]);

  useEffect(() => {
    if (!started) return;
    const duration = 1500;
    const start = performance.now();
    const animate = (now: number) => {
      const elapsed = now - start;
      const progress = Math.min(elapsed / duration, 1);
      const eased = 1 - Math.pow(1 - progress, 3);
      setValue(Math.round(eased * end));
      if (progress < 1) requestAnimationFrame(animate);
    };
    requestAnimationFrame(animate);
  }, [started, end]);

  return <span ref={ref}>{prefix}{value.toLocaleString()}{suffix}</span>;
}

export default function ToolComparison() {
  const [isVisible, setIsVisible] = useState(false);
  const ref = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setIsVisible(true);
          observer.disconnect();
        }
      },
      { threshold: 0.1 }
    );
    if (ref.current) observer.observe(ref.current);
    return () => observer.disconnect();
  }, []);

  const totalGuru = tools.reduce((acc, t) => {
    const match = t.guruCost.match(/\$(\d+)/);
    return acc + (match ? parseInt(match[1]) : 0);
  }, 0);

  return (
    <section ref={ref} id="stack" className="py-20 px-4">
      <div className="max-w-5xl mx-auto">
        <div className={cn(
          'transition-all duration-700',
          isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'
        )}>
          <div className="text-center mb-10">
            <span className="text-xs font-mono tracking-widest text-neon-red mb-3 block">THE PROOF — COST ANALYSIS</span>
            <h2 className="text-3xl sm:text-4xl font-bold text-steel-100 mb-3">
              <span className="text-neon-red">Guru Stack</span> vs <span className="text-neon-green">Sovereign Stack</span>
            </h2>
            <p className="text-steel-400 max-w-xl mx-auto text-sm">
              See exactly where the "Success Penalty" is bleeding your profits. Every tool below has a $0/mo sovereign replacement.
            </p>
          </div>

          {/* Savings Counter */}
          <div className="text-center mb-8">
            <div className="inline-flex items-center gap-4 glass-card rounded-2xl px-8 py-5 border border-neon-green/20">
              <div className="text-left">
                <div className="text-xs text-steel-400 font-mono mb-1">YOU'RE SAVING</div>
                <div className="text-3xl sm:text-4xl font-black text-neon-green">
                  <AnimatedCounter end={totalGuru * 12} suffix="/yr" />
                </div>
              </div>
              <div className="w-px h-12 bg-dark-500" />
              <div className="text-left">
                <div className="text-xs text-steel-400 font-mono mb-1">YOUR NEW COST</div>
                <div className="text-3xl sm:text-4xl font-black text-neon-green">$0/yr</div>
              </div>
            </div>
          </div>

          <div className="glass-card rounded-2xl border border-dark-500 overflow-hidden">
            {/* Desktop table */}
            <div className="hidden sm:block overflow-x-auto">
              <table className="w-full">
                <thead>
                  <tr className="border-b border-dark-500">
                    <th className="text-left text-xs font-mono text-steel-400 p-4">FUNCTION</th>
                    <th className="text-left text-xs font-mono text-neon-red p-4">
                      <div className="flex items-center gap-1.5">
                        <Skull className="w-3.5 h-3.5" />
                        GURU STACK
                      </div>
                    </th>
                    <th className="text-left text-xs font-mono text-steel-400 p-4">COST</th>
                    <th className="text-center p-4"><ArrowRight className="w-4 h-4 text-steel-500 mx-auto" /></th>
                    <th className="text-left text-xs font-mono text-neon-green p-4">
                      <div className="flex items-center gap-1.5">
                        <Shield className="w-3.5 h-3.5" />
                        SOVEREIGN
                      </div>
                    </th>
                    <th className="text-left text-xs font-mono text-steel-400 p-4">COST</th>
                  </tr>
                </thead>
                <tbody>
                  {tools.map((tool, i) => (
                    <tr key={i} className={cn(
                      'border-b border-dark-600/50 hover:bg-dark-700/30 transition-all duration-500',
                      isVisible ? 'opacity-100' : 'opacity-0'
                    )} style={{ transitionDelay: `${i * 100}ms` }}>
                      <td className="p-4 text-sm text-steel-200 font-medium">{tool.function_name}</td>
                      <td className="p-4">
                        <div className="flex items-center gap-1.5">
                          <X className="w-3.5 h-3.5 text-neon-red" />
                          <span className="text-sm text-steel-400">{tool.guru}</span>
                        </div>
                      </td>
                      <td className="p-4 text-sm text-neon-red font-mono">{tool.guruCost}</td>
                      <td className="p-4 text-center"><ArrowRight className="w-3 h-3 text-steel-600 mx-auto" /></td>
                      <td className="p-4">
                        <div className="flex items-center gap-1.5">
                          <Check className="w-3.5 h-3.5 text-neon-green" />
                          <span className="text-sm text-neon-green font-medium">{tool.sovereign}</span>
                        </div>
                      </td>
                      <td className="p-4 text-sm text-neon-green font-mono font-bold">{tool.sovereignCost}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>

            {/* Mobile view */}
            <div className="sm:hidden divide-y divide-dark-600">
              {tools.map((tool, i) => (
                <div key={i} className="p-4 space-y-2">
                  <div className="text-sm font-medium text-steel-200">{tool.function_name}</div>
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-1.5">
                      <X className="w-3 h-3 text-neon-red" />
                      <span className="text-xs text-steel-400">{tool.guru}</span>
                    </div>
                    <span className="text-xs text-neon-red font-mono">{tool.guruCost}</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-1.5">
                      <Check className="w-3 h-3 text-neon-green" />
                      <span className="text-xs text-neon-green">{tool.sovereign}</span>
                    </div>
                    <span className="text-xs text-neon-green font-mono font-bold">{tool.sovereignCost}</span>
                  </div>
                </div>
              ))}
            </div>

            {/* Total */}
            <div className="border-t-2 border-dark-500 p-4 sm:p-5 bg-dark-700/30">
              <div className="flex items-center justify-between">
                <span className="text-sm font-mono text-steel-300">ANNUAL TOTAL</span>
                <div className="flex items-center gap-4 sm:gap-8">
                  <div className="text-right">
                    <div className="text-lg sm:text-xl font-black text-neon-red line-through">${(totalGuru * 12).toLocaleString()}/yr</div>
                    <div className="text-[10px] text-steel-500">Guru Stack</div>
                  </div>
                  <ArrowRight className="w-4 h-4 text-neon-green" />
                  <div className="text-right">
                    <div className="text-lg sm:text-xl font-black text-neon-green">$0/yr</div>
                    <div className="text-[10px] text-steel-500">Sovereign Stack</div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
