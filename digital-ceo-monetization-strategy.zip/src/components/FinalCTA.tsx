import { useState, useEffect, useRef } from 'react';
import { Factory, ArrowRight, Shield, Zap, Crown } from 'lucide-react';
import { cn } from '../utils/cn';

export default function FinalCTA() {
  const [isVisible, setIsVisible] = useState(false);
  const ref = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setIsVisible(true);
          observer.disconnect();
        }
      },
      { threshold: 0.2 }
    );
    if (ref.current) observer.observe(ref.current);
    return () => observer.disconnect();
  }, []);

  return (
    <section ref={ref} className="py-20 px-4">
      <div className="max-w-3xl mx-auto">
        <div className={cn(
          'transition-all duration-700',
          isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'
        )}>
          {/* CEO Verdict */}
          <div className="relative rounded-2xl overflow-hidden mb-12">
            <div className="absolute inset-0 rounded-2xl p-[2px]"
              style={{ background: 'linear-gradient(135deg, #39e75f, #00d4ff, #a855f7, #39e75f)' }}>
              <div className="w-full h-full rounded-2xl bg-dark-800" />
            </div>

            <div className="relative z-10 p-8 sm:p-10">
              <div className="flex items-center gap-3 mb-6">
                <Crown className="w-7 h-7 text-neon-yellow" />
                <span className="text-sm font-mono tracking-widest text-neon-yellow font-bold">CEO VERDICT</span>
              </div>

              <blockquote className="text-xl sm:text-2xl font-bold text-steel-100 leading-relaxed mb-6">
                "Selling is a <span className="gradient-text-warm">'wealth skill'</span> rooted in communication. 
                Once you use these keywords to build{' '}
                <span className="gradient-text">Search Intent Infrastructure</span>, 
                you stop chasing clicks and start{' '}
                <span className="text-neon-green">owning the engine</span> that manufactures them."
              </blockquote>

              <div className="flex items-center gap-4 text-sm text-steel-400">
                <span className="flex items-center gap-1.5">
                  <Shield className="w-4 h-4 text-neon-green" /> Sovereign
                </span>
                <span className="flex items-center gap-1.5">
                  <Zap className="w-4 h-4 text-neon-yellow" /> Automated
                </span>
                <span className="flex items-center gap-1.5">
                  <Factory className="w-4 h-4 text-neon-blue" /> Owned
                </span>
              </div>
            </div>
          </div>

          {/* Final CTA */}
          <div className="text-center">
            <h3 className="text-2xl sm:text-3xl font-black text-steel-100 mb-3">
              Ready to stop bleeding profit?
            </h3>
            <p className="text-steel-400 mb-8 max-w-md mx-auto">
              Initialize your Invisible Factory for $1. No subscriptions. No guru tax. Full sovereignty.
            </p>

            <div className="relative inline-block mb-4">
              <div className="absolute inset-0 rounded-2xl animate-money-pulse opacity-50" />
              <button
                className="money-button text-xl sm:text-2xl px-12 sm:px-16 py-5 sm:py-6 rounded-2xl inline-flex items-center gap-3 relative z-10"
                onClick={() => window.open('#', '_blank')}
              >
                INITIALIZE MY FACTORY ($1)
                <span className="text-2xl">🛠️</span>
              </button>
            </div>

            <p className="text-xs text-steel-500 font-mono flex items-center justify-center gap-2">
              <ArrowRight className="w-3 h-3" />
              Powered by Payhip Fortress — $0/mo overhead
            </p>
          </div>
        </div>
      </div>
    </section>
  );
}
