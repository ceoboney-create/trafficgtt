import { useState, useEffect } from 'react';
import { Factory, AlertTriangle, ChevronDown } from 'lucide-react';

export default function Hero() {
  const [visible, setVisible] = useState(false);
  const [showSub, setShowSub] = useState(false);
  const [dollarCount, setDollarCount] = useState(0);

  useEffect(() => {
    setVisible(true);
    const t = setTimeout(() => setShowSub(true), 600);
    return () => clearTimeout(t);
  }, []);

  useEffect(() => {
    if (!visible) return;
    const target = 5000;
    const duration = 2000;
    const start = performance.now();
    const animate = (now: number) => {
      const elapsed = now - start;
      const progress = Math.min(elapsed / duration, 1);
      const eased = 1 - Math.pow(1 - progress, 3);
      setDollarCount(Math.round(eased * target));
      if (progress < 1) requestAnimationFrame(animate);
    };
    requestAnimationFrame(animate);
  }, [visible]);

  return (
    <section className="relative min-h-screen flex items-center justify-center overflow-hidden px-4 pt-16 pb-8">
      {/* Background grid */}
      <div className="absolute inset-0 opacity-[0.03]" style={{
        backgroundImage: 'linear-gradient(rgba(255,51,102,0.5) 1px, transparent 1px), linear-gradient(90deg, rgba(255,51,102,0.5) 1px, transparent 1px)',
        backgroundSize: '60px 60px'
      }} />

      {/* Red warning glow at top */}
      <div className="absolute top-0 left-1/2 -translate-x-1/2 w-[1000px] h-[400px] opacity-20"
        style={{ background: 'radial-gradient(ellipse at top, rgba(255,51,102,0.3), transparent 70%)' }} />

      {/* Green glow at bottom */}
      <div className="absolute bottom-0 left-1/2 -translate-x-1/2 w-[800px] h-[400px] opacity-15"
        style={{ background: 'radial-gradient(ellipse at bottom, rgba(57,231,95,0.3), transparent 70%)' }} />

      <div className={`relative z-10 text-center max-w-4xl mx-auto transition-all duration-1000 ${visible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-10'}`}>
        
        {/* Warning Badge */}
        <div className="inline-flex items-center gap-2 bg-neon-red/10 border border-neon-red/30 rounded-full px-5 py-2 mb-8">
          <AlertTriangle className="w-4 h-4 text-neon-red animate-pulse-glow" />
          <span className="text-xs font-mono tracking-wider text-neon-red uppercase">Profit Leak Detected</span>
          <AlertTriangle className="w-4 h-4 text-neon-red animate-pulse-glow" />
        </div>

        {/* Main Headline */}
        <h1 className="text-4xl sm:text-5xl md:text-7xl font-black mb-6 leading-[1.1]">
          <span className="block text-steel-100">STOP GETTING</span>
          <span className="block text-steel-100">ROBBED BY YOUR</span>
          <span className="block text-steel-100">OWN BUSINESS.</span>
          <span className="block text-5xl sm:text-6xl md:text-8xl mt-2">💸</span>
        </h1>

        {/* Sub-headline */}
        <div className={`transition-all duration-700 delay-300 ${showSub ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-4'}`}>
          <p className="text-lg sm:text-xl md:text-2xl text-steel-300 max-w-3xl mx-auto mb-8 leading-relaxed">
            The <span className="text-neon-red font-bold">"Guru Tax"</span> is costing you{' '}
            <span className="text-neon-red font-black text-2xl sm:text-3xl">${dollarCount.toLocaleString()}/year</span>{' '}
            in hidden rent. I'm declassifying the{' '}
            <span className="text-neon-green font-bold">Invisible Factory</span>—the{' '}
            <span className="text-money-green font-black text-2xl sm:text-3xl">$1</span> infrastructure that turns{' '}
            <span className="text-neon-blue font-semibold">AI search theft</span> into your{' '}
            <span className="text-neon-green font-semibold">private lead machine</span>.
          </p>
        </div>

        {/* Urgency Stats */}
        <div className="flex flex-wrap items-center justify-center gap-4 mb-10">
          <div className="glass-card-red rounded-xl px-5 py-3 flex items-center gap-3">
            <div className="text-left">
              <div className="text-xl font-black text-neon-red line-through">$5,000/yr</div>
              <div className="text-[10px] text-steel-400 font-mono">GURU STACK COST</div>
            </div>
          </div>
          <div className="text-2xl text-steel-500">→</div>
          <div className="glass-card rounded-xl px-5 py-3 flex items-center gap-3 border-money-green/30 animate-money-pulse">
            <Factory className="w-5 h-5 text-money-green" />
            <div className="text-left">
              <div className="text-xl font-black text-money-green">$1 to start</div>
              <div className="text-[10px] text-steel-400 font-mono">INVISIBLE FACTORY</div>
            </div>
          </div>
        </div>

        {/* CTA */}
        <div className="flex flex-col items-center gap-4">
          <a
            href="#offer"
            className="money-button text-lg sm:text-xl px-10 py-4 rounded-2xl inline-flex items-center gap-3"
          >
            INITIALIZE MY FACTORY ($1) 🛠️
          </a>
          <span className="text-xs text-steel-500 font-mono">$0/mo overhead • No subscriptions • You own everything</span>
        </div>

        <div className="mt-12">
          <a href="#answer-box" className="inline-flex flex-col items-center gap-1 text-steel-400 hover:text-neon-green transition-colors group">
            <span className="text-xs tracking-widest uppercase font-mono">See what's inside</span>
            <ChevronDown className="w-5 h-5 group-hover:translate-y-1 transition-transform" />
          </a>
        </div>
      </div>
    </section>
  );
}
