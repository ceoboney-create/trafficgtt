import { useState, useEffect, useRef } from 'react';
import { Factory, Wrench, Share2, Bot, Check, Zap, ArrowRight, Lock } from 'lucide-react';
import { cn } from '../utils/cn';

const offerItems = [
  {
    icon: <Wrench className="w-6 h-6 text-neon-green" />,
    title: 'Decommission the Guru Stack',
    description: 'Plug the $5,000/year leak in 30 minutes. Step-by-step teardown of every overpriced tool and its sovereign replacement.',
    highlight: '30 MIN SETUP',
    color: 'neon-green',
  },
  {
    icon: <Share2 className="w-6 h-6 text-neon-blue" />,
    title: 'Build the Context Bridge',
    description: 'Use automation (n8n) to move users from public feeds to your private fortress. No coding required — copy the exact workflows.',
    highlight: 'AUTOMATION',
    color: 'neon-blue',
  },
  {
    icon: <Bot className="w-6 h-6 text-neon-purple" />,
    title: 'Claim the AI Visibility Index',
    description: 'Format your content so the AI robots promote YOU for free. The exact templates that get cited by ChatGPT, Gemini, and Perplexity.',
    highlight: 'AI-PROOF',
    color: 'neon-purple',
  },
];

export default function FactoryOffer() {
  const [isVisible, setIsVisible] = useState(false);
  const [hoveredCta, setHoveredCta] = useState(false);
  const ref = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setIsVisible(true);
          observer.disconnect();
        }
      },
      { threshold: 0.1 }
    );
    if (ref.current) observer.observe(ref.current);
    return () => observer.disconnect();
  }, []);

  return (
    <section ref={ref} id="offer" className="py-20 px-4">
      <div className="max-w-4xl mx-auto">
        <div className={cn(
          'transition-all duration-700',
          isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'
        )}>
          {/* Section Header */}
          <div className="text-center mb-6">
            <div className="inline-flex items-center gap-2 mb-4">
              <Factory className="w-5 h-5 text-money-green animate-pulse-glow" />
              <span className="text-xs font-mono tracking-widest text-money-green uppercase">The Offer</span>
            </div>
            <h2 className="text-3xl sm:text-4xl md:text-5xl font-black text-steel-100 mb-4">
              Initialize Your Factory for{' '}
              <span className="gradient-text-money text-4xl sm:text-5xl md:text-6xl">$1</span>
            </h2>
            <p className="text-lg text-steel-300 max-w-2xl mx-auto">
              I've mapped out the <span className="text-neon-green font-bold">14-Day Traffic Blitz</span> to show you exactly how to manufacture buyer clicks from raw data without the Guru fluff.
            </p>
          </div>

          {/* Offer Label */}
          <div className="text-center mb-10">
            <div className="inline-flex items-center gap-2 glass-card rounded-full px-6 py-2 border border-neon-green/20">
              <Zap className="w-4 h-4 text-neon-yellow" />
              <span className="text-sm font-mono text-steel-200">Inside the <span className="text-neon-green font-bold">$1 Factory Map</span>:</span>
            </div>
          </div>

          {/* Three Offer Cards */}
          <div className="space-y-4 mb-14">
            {offerItems.map((item, i) => (
              <div
                key={i}
                className={cn(
                  'glass-card rounded-2xl p-6 sm:p-8 border border-dark-500 hover:border-neon-green/30 transition-all duration-500',
                  isVisible ? 'opacity-100 translate-x-0' : 'opacity-0 -translate-x-8'
                )}
                style={{ transitionDelay: `${300 + i * 200}ms` }}
              >
                <div className="flex items-start gap-5">
                  {/* Number */}
                  <div className="flex-shrink-0">
                    <div className="w-12 h-12 rounded-xl bg-dark-600 border border-dark-500 flex items-center justify-center">
                      {item.icon}
                    </div>
                  </div>
                  <div className="flex-1">
                    <div className="flex items-center gap-3 mb-2 flex-wrap">
                      <h3 className="text-lg sm:text-xl font-bold text-steel-100">{item.title}</h3>
                      <span className={cn(
                        'text-[10px] font-mono px-2 py-0.5 rounded-full border',
                        `text-${item.color} bg-${item.color}/10 border-${item.color}/20`
                      )}>
                        {item.highlight}
                      </span>
                    </div>
                    <p className="text-sm text-steel-300 leading-relaxed">{item.description}</p>
                  </div>
                  <div className="flex-shrink-0 hidden sm:flex items-center">
                    <Check className="w-5 h-5 text-neon-green" />
                  </div>
                </div>
              </div>
            ))}
          </div>

          {/* Kill-Switch CTA */}
          <div className="text-center">
            {/* Pre-CTA trust signals */}
            <div className="flex flex-wrap items-center justify-center gap-4 sm:gap-6 mb-6">
              <div className="flex items-center gap-1.5 text-xs text-steel-400">
                <Check className="w-3.5 h-3.5 text-neon-green" />
                <span>No monthly fees</span>
              </div>
              <div className="flex items-center gap-1.5 text-xs text-steel-400">
                <Check className="w-3.5 h-3.5 text-neon-green" />
                <span>Instant access</span>
              </div>
              <div className="flex items-center gap-1.5 text-xs text-steel-400">
                <Check className="w-3.5 h-3.5 text-neon-green" />
                <span>Powered by Payhip</span>
              </div>
              <div className="flex items-center gap-1.5 text-xs text-steel-400">
                <Lock className="w-3.5 h-3.5 text-neon-green" />
                <span>$0/mo overhead</span>
              </div>
            </div>

            {/* The Big Money Button */}
            <div className="relative inline-block">
              {/* Glow ring behind button */}
              <div className="absolute inset-0 rounded-2xl animate-money-pulse opacity-50" />
              
              <button
                className={cn(
                  'money-button text-xl sm:text-2xl px-12 sm:px-16 py-5 sm:py-6 rounded-2xl inline-flex items-center gap-3 relative z-10',
                  hoveredCta ? 'scale-105' : ''
                )}
                onMouseEnter={() => setHoveredCta(true)}
                onMouseLeave={() => setHoveredCta(false)}
                onClick={() => window.open('#', '_blank')}
              >
                INITIALIZE MY FACTORY ($1)
                <span className="text-2xl">🛠️</span>
              </button>
            </div>

            <p className="mt-4 text-xs text-steel-500 font-mono flex items-center justify-center gap-2">
              <ArrowRight className="w-3 h-3" />
              Powered by Payhip Fortress — $0/mo overhead
            </p>

            {/* Urgency note */}
            <div className="mt-8 inline-flex items-center gap-2 bg-neon-orange/5 border border-neon-orange/20 rounded-xl px-5 py-3">
              <Zap className="w-4 h-4 text-neon-orange" />
              <span className="text-xs text-steel-300">
                <span className="text-neon-orange font-bold">Note:</span> This button points directly to your Payhip Fortress for $0/mo overhead.
              </span>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
