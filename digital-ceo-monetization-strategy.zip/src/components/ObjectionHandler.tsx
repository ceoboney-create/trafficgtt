import { useState, useEffect, useRef } from 'react';
import { ChevronDown, HelpCircle } from 'lucide-react';
import { cn } from '../utils/cn';

const objections = [
  {
    q: '"Is this just another course?"',
    a: 'No. This is a tactical infrastructure map — not theory or motivation. You get the exact tools, workflows, and templates to replace your entire Guru Stack in 30 minutes and build an AI-proof lead machine in 14 days.',
  },
  {
    q: '"Why only $1? What\'s the catch?"',
    a: "There's no catch. The $1 price eliminates friction so you can see the system works. Once you plug the $5,000/year leak, you'll understand why the factory pays for itself 5,000× over.",
  },
  {
    q: '"I\'m not technical. Can I do this?"',
    a: 'If you can copy and paste, you can build this. Every step uses no-code tools — Payhip, LeadsLeap, and n8n visual workflows. No coding required.',
  },
  {
    q: '"What about AI stealing my content?"',
    a: "That's exactly what the GEO optimization module solves. Instead of fighting AI, you format your content so AI engines are forced to cite YOU as the source — turning the threat into free distribution.",
  },
  {
    q: '"Do I need to cancel my current tools immediately?"',
    a: "No. The map shows you how to migrate gradually. But most people kill their Guru Stack within the first week once they see the sovereign alternatives working.",
  },
];

export default function ObjectionHandler() {
  const [isVisible, setIsVisible] = useState(false);
  const [openIndex, setOpenIndex] = useState<number | null>(null);
  const ref = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setIsVisible(true);
          observer.disconnect();
        }
      },
      { threshold: 0.1 }
    );
    if (ref.current) observer.observe(ref.current);
    return () => observer.disconnect();
  }, []);

  return (
    <section ref={ref} className="py-16 px-4">
      <div className="max-w-3xl mx-auto">
        <div className={cn(
          'transition-all duration-700',
          isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'
        )}>
          <div className="text-center mb-10">
            <div className="flex items-center justify-center gap-2 mb-3">
              <HelpCircle className="w-5 h-5 text-steel-400" />
              <span className="text-xs font-mono tracking-widest text-steel-400 uppercase">Objection Handling</span>
            </div>
            <h3 className="text-2xl sm:text-3xl font-bold text-steel-100">
              Still on the fence? <span className="gradient-text">Good.</span>
            </h3>
            <p className="text-sm text-steel-400 mt-2">Skepticism means you think like a CEO, not a follower.</p>
          </div>

          <div className="space-y-3">
            {objections.map((obj, i) => (
              <div
                key={i}
                className={cn(
                  'glass-card rounded-xl border transition-all duration-300 cursor-pointer',
                  openIndex === i ? 'border-neon-green/30' : 'border-dark-500 hover:border-dark-400'
                )}
                onClick={() => setOpenIndex(openIndex === i ? null : i)}
              >
                <div className="flex items-center justify-between p-5 gap-3">
                  <span className="text-sm sm:text-base font-semibold text-steel-200">{obj.q}</span>
                  <ChevronDown className={cn(
                    'w-4 h-4 text-steel-400 transition-transform flex-shrink-0',
                    openIndex === i && 'rotate-180 text-neon-green'
                  )} />
                </div>
                <div className={cn(
                  'overflow-hidden transition-all duration-300',
                  openIndex === i ? 'max-h-[300px] opacity-100' : 'max-h-0 opacity-0'
                )}>
                  <div className="px-5 pb-5 border-t border-dark-600 pt-4">
                    <p className="text-sm text-steel-300 leading-relaxed">{obj.a}</p>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
