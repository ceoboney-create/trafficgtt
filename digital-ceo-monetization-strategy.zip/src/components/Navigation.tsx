import { useState, useEffect } from 'react';
import { Factory, Menu, X } from 'lucide-react';
import { cn } from '../utils/cn';

const links = [
  { label: 'The Problem', href: '#reality' },
  { label: 'The Proof', href: '#stack' },
  { label: 'The Offer', href: '#offer' },
  { label: 'Initialize →', href: '#offer', isCta: true },
];

export default function Navigation() {
  const [scrolled, setScrolled] = useState(false);
  const [menuOpen, setMenuOpen] = useState(false);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 50);
    window.addEventListener('scroll', onScroll);
    return () => window.removeEventListener('scroll', onScroll);
  }, []);

  return (
    <nav className={cn(
      'fixed top-0 left-0 right-0 z-50 transition-all duration-300',
      scrolled ? 'bg-dark-900/90 backdrop-blur-xl border-b border-dark-600' : 'bg-transparent'
    )}>
      <div className="max-w-6xl mx-auto px-4 h-14 flex items-center justify-between">
        <a href="#" className="flex items-center gap-2 group">
          <Factory className="w-5 h-5 text-neon-green group-hover:rotate-12 transition-transform" />
          <span className="text-sm font-mono font-bold text-steel-100 hidden sm:block">
            INVISIBLE<span className="text-neon-green">_</span>FACTORY
          </span>
        </a>

        {/* Desktop links */}
        <div className="hidden sm:flex items-center gap-6">
          {links.map(link => (
            <a
              key={link.label}
              href={link.href}
              className={cn(
                'text-xs font-mono tracking-wider transition-colors',
                link.isCta
                  ? 'text-dark-900 bg-money-green hover:bg-neon-green px-4 py-1.5 rounded-full font-bold'
                  : 'text-steel-400 hover:text-neon-green'
              )}
            >
              {link.label}
            </a>
          ))}
        </div>

        {/* Mobile menu button */}
        <button
          className="sm:hidden text-steel-300 hover:text-neon-green transition-colors"
          onClick={() => setMenuOpen(!menuOpen)}
        >
          {menuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
        </button>
      </div>

      {/* Mobile menu */}
      {menuOpen && (
        <div className="sm:hidden bg-dark-800/95 backdrop-blur-xl border-b border-dark-600">
          <div className="px-4 py-4 space-y-3">
            {links.map(link => (
              <a
                key={link.label}
                href={link.href}
                className={cn(
                  'block text-sm font-mono transition-colors',
                  link.isCta
                    ? 'text-dark-900 bg-money-green hover:bg-neon-green px-4 py-2 rounded-lg font-bold text-center'
                    : 'text-steel-300 hover:text-neon-green'
                )}
                onClick={() => setMenuOpen(false)}
              >
                {link.label}
              </a>
            ))}
          </div>
        </div>
      )}
    </nav>
  );
}
