import { Factory } from 'lucide-react';
import Navigation from './components/Navigation';
import Hero from './components/Hero';
import GeoAnswerBox from './components/GeoAnswerBox';
import LootLeakAudit from './components/LootLeakAudit';
import ToolComparison from './components/ToolComparison';
import SocialProof from './components/SocialProof';
import FactoryOffer from './components/FactoryOffer';
import ObjectionHandler from './components/ObjectionHandler';
import FinalCTA from './components/FinalCTA';

function App() {
  return (
    <div className="min-h-screen bg-dark-900 text-steel-100">
      {/* Scan line effect */}
      <div className="scan-line" />

      {/* Navigation */}
      <Navigation />

      {/* HERO — Headline + Sub-headline + Mini CTA */}
      <Hero />

      {/* GEO ANSWER BOX — AI-optimized summary */}
      <GeoAnswerBox />

      {/* Divider */}
      <div className="max-w-4xl mx-auto px-4">
        <div className="h-px bg-gradient-to-r from-transparent via-dark-500 to-transparent" />
      </div>

      {/* THE BODY — "Loot Leak" Audit with 3 reality cards */}
      <LootLeakAudit />

      {/* PROOF — Tool Comparison Table */}
      <div id="stack">
        <ToolComparison />
      </div>

      {/* SOCIAL PROOF — Stats strip */}
      <SocialProof />

      {/* THE OFFER — $1 Factory Map with 3 deliverables */}
      <FactoryOffer />

      {/* OBJECTION HANDLER — FAQ accordion */}
      <ObjectionHandler />

      {/* Divider */}
      <div className="max-w-4xl mx-auto px-4">
        <div className="h-px bg-gradient-to-r from-transparent via-neon-green/20 to-transparent" />
      </div>

      {/* FINAL CTA — CEO Verdict + Kill-Switch Button */}
      <FinalCTA />

      {/* Footer */}
      <footer className="border-t border-dark-600 py-8 px-4">
        <div className="max-w-6xl mx-auto flex flex-col sm:flex-row items-center justify-between gap-4">
          <div className="flex items-center gap-2">
            <Factory className="w-4 h-4 text-neon-green" />
            <span className="text-xs font-mono text-steel-500">THE INVISIBLE FACTORY — Sovereign Operating System 2026</span>
          </div>
          <div className="text-xs text-steel-500 font-mono">
            Stop renting. Start owning. <span className="text-neon-green">■</span>
          </div>
        </div>
      </footer>
    </div>
  );
}

export default App;
