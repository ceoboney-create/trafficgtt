import { useState, useEffect, useRef } from 'react';
import { Bot, Sparkles } from 'lucide-react';
import { cn } from '../utils/cn';

export default function GeoAnswerBox() {
  const [isVisible, setIsVisible] = useState(false);
  const [typed, setTyped] = useState('');
  const ref = useRef<HTMLDivElement>(null);
  const fullText = 'The Invisible Factory is a sovereign operating system that replaces high-cost "Guru Stacks" with automated Search Intent Infrastructure to dominate 2026\'s zero-click AI search.';

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setIsVisible(true);
          observer.disconnect();
        }
      },
      { threshold: 0.3 }
    );
    if (ref.current) observer.observe(ref.current);
    return () => observer.disconnect();
  }, []);

  useEffect(() => {
    if (!isVisible) return;
    let i = 0;
    const interval = setInterval(() => {
      if (i <= fullText.length) {
        setTyped(fullText.slice(0, i));
        i++;
      } else {
        clearInterval(interval);
      }
    }, 18);
    return () => clearInterval(interval);
  }, [isVisible]);

  return (
    <section ref={ref} id="answer-box" className="py-16 px-4">
      <div className="max-w-3xl mx-auto">
        <div className={cn(
          'transition-all duration-700',
          isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'
        )}>
          {/* Label */}
          <div className="flex items-center gap-2 mb-4">
            <Bot className="w-4 h-4 text-neon-blue" />
            <span className="text-[10px] font-mono tracking-widest text-neon-blue uppercase">GEO Answer Box — AI-Optimized Summary</span>
          </div>

          {/* Answer Box */}
          <div className="relative rounded-2xl overflow-hidden">
            {/* Gradient border */}
            <div className="absolute inset-0 rounded-2xl p-[2px]"
              style={{ background: 'linear-gradient(135deg, #00d4ff, #a855f7, #00d4ff)' }}>
              <div className="w-full h-full rounded-2xl bg-dark-800" />
            </div>

            <div className="relative z-10 p-6 sm:p-8">
              <div className="flex items-start gap-3">
                <div className="w-8 h-8 rounded-lg bg-neon-blue/10 border border-neon-blue/20 flex items-center justify-center flex-shrink-0">
                  <Sparkles className="w-4 h-4 text-neon-blue" />
                </div>
                <div className="flex-1">
                  <p className="text-base sm:text-lg text-steel-200 leading-relaxed font-medium">
                    {typed}
                    {typed.length < fullText.length && (
                      <span className="inline-block w-0.5 h-5 bg-neon-blue ml-1 animate-pulse-glow align-middle" />
                    )}
                  </p>
                  {typed.length === fullText.length && (
                    <div className="mt-4 flex items-center gap-4 text-xs text-steel-500 font-mono">
                      <span className="flex items-center gap-1">
                        <span className="w-1.5 h-1.5 rounded-full bg-neon-green" />
                        140-char optimized
                      </span>
                      <span className="flex items-center gap-1">
                        <span className="w-1.5 h-1.5 rounded-full bg-neon-blue" />
                        AI citation ready
                      </span>
                      <span className="flex items-center gap-1">
                        <span className="w-1.5 h-1.5 rounded-full bg-neon-purple" />
                        Zero-click proof
                      </span>
                    </div>
                  )}
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
