import { useState, useEffect, useRef } from 'react';
import { TrendingUp, Star, Users, Clock } from 'lucide-react';
import { cn } from '../utils/cn';

const proofPoints = [
  {
    icon: <TrendingUp className="w-5 h-5 text-neon-green" />,
    stat: '32×',
    label: 'Traffic Multiplier',
    desc: 'Moving keywords from position 15 to #1',
  },
  {
    icon: <Clock className="w-5 h-5 text-neon-blue" />,
    stat: '14 Days',
    label: 'Traffic Blitz',
    desc: 'Full system initialization timeline',
  },
  {
    icon: <Users className="w-5 h-5 text-neon-purple" />,
    stat: '$0/mo',
    label: 'Overhead Cost',
    desc: 'After sovereign stack deployment',
  },
  {
    icon: <Star className="w-5 h-5 text-neon-yellow" />,
    stat: '100%',
    label: 'Ownership',
    desc: 'You own every asset you build',
  },
];

export default function SocialProof() {
  const [isVisible, setIsVisible] = useState(false);
  const ref = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setIsVisible(true);
          observer.disconnect();
        }
      },
      { threshold: 0.2 }
    );
    if (ref.current) observer.observe(ref.current);
    return () => observer.disconnect();
  }, []);

  return (
    <section ref={ref} className="py-16 px-4 border-y border-dark-600">
      <div className="max-w-5xl mx-auto">
        <div className={cn(
          'transition-all duration-700',
          isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'
        )}>
          <div className="text-center mb-8">
            <span className="text-xs font-mono tracking-widest text-steel-400">BY THE NUMBERS</span>
          </div>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 sm:gap-6">
            {proofPoints.map((point, i) => (
              <div
                key={i}
                className={cn(
                  'text-center p-5 rounded-2xl glass-card border border-dark-500 transition-all duration-500',
                  isVisible ? 'opacity-100 scale-100' : 'opacity-0 scale-90'
                )}
                style={{ transitionDelay: `${i * 150}ms` }}
              >
                <div className="flex justify-center mb-3">{point.icon}</div>
                <div className="text-2xl sm:text-3xl font-black gradient-text mb-1">{point.stat}</div>
                <div className="text-xs font-mono text-steel-200 mb-1">{point.label}</div>
                <div className="text-[10px] text-steel-500">{point.desc}</div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
