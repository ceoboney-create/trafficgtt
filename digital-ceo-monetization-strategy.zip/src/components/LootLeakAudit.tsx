import { useState, useEffect, useRef } from 'react';
import { AlertTriangle, Ghost, DollarSign, Shield, TrendingDown } from 'lucide-react';
import { cn } from '../utils/cn';

const leaks = [
  {
    icon: <Ghost className="w-6 h-6 text-neon-red" />,
    title: 'The Click is Dead',
    stat: '65%',
    statLabel: 'of searches = zero clicks',
    description: 'AI is stealing your traffic and answering questions directly on the search page. Your carefully crafted content gets summarized and served without a single visit to your site.',
    color: 'red' as const,
  },
  {
    icon: <DollarSign className="w-6 h-6 text-neon-orange" />,
    title: 'The Rent is Too High',
    stat: '$432',
    statLabel: '/month in SaaS fees',
    description: "You're paying thousands for funnels and CRMs that penalize your growth. Every new customer increases your software bill. That's not leverage — that's a tax on success.",
    color: 'orange' as const,
  },
  {
    icon: <Shield className="w-6 h-6 text-neon-green" />,
    title: 'The Solution is Sovereign',
    stat: '$0',
    statLabel: '/month overhead',
    description: 'You need an owned infrastructure that AI has to cite as the authority. No more renting. No more platform dependency. Build once, own forever.',
    color: 'green' as const,
  },
];

export default function LootLeakAudit() {
  const [isVisible, setIsVisible] = useState(false);
  const [activeCard, setActiveCard] = useState<number | null>(null);
  const ref = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setIsVisible(true);
          observer.disconnect();
        }
      },
      { threshold: 0.1 }
    );
    if (ref.current) observer.observe(ref.current);
    return () => observer.disconnect();
  }, []);

  const borderColors = {
    red: 'border-neon-red/30 hover:border-neon-red/60',
    orange: 'border-neon-orange/30 hover:border-neon-orange/60',
    green: 'border-neon-green/30 hover:border-neon-green/60',
  };

  const statColors = {
    red: 'text-neon-red',
    orange: 'text-neon-orange',
    green: 'text-neon-green',
  };

  return (
    <section ref={ref} id="reality" className="py-20 px-4">
      <div className="max-w-4xl mx-auto">
        <div className={cn(
          'transition-all duration-700',
          isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'
        )}>
          {/* Section Header */}
          <div className="text-center mb-6">
            <div className="inline-flex items-center gap-2 mb-4">
              <AlertTriangle className="w-5 h-5 text-neon-red" />
              <span className="text-xs font-mono tracking-widest text-neon-red uppercase">The "Loot Leak" Audit</span>
            </div>
            <h2 className="text-3xl sm:text-4xl md:text-5xl font-black text-steel-100 mb-4">
              The Reality Check for <span className="gradient-text-warm">2026</span>
            </h2>
          </div>

          {/* Opening Quote */}
          <div className="max-w-2xl mx-auto mb-12">
            <div className="glass-card-red rounded-2xl p-6 sm:p-8 border border-neon-red/20">
              <div className="flex gap-3">
                <TrendingDown className="w-6 h-6 text-neon-red flex-shrink-0 mt-1" />
                <p className="text-base sm:text-lg text-steel-200 leading-relaxed italic">
                  "Listen, if your software bill goes up every time you get a new customer, you aren't a business owner—<span className="text-neon-red font-bold not-italic">you're a tenant</span>. Most people are stuck in a{' '}
                  <span className="text-neon-orange font-bold not-italic">'Success Penalty'</span> loop, bleeding profit to pay for a 'Guru Stack' they don't even own."
                </p>
              </div>
            </div>
          </div>

          {/* Three Reality Cards */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-5">
            {leaks.map((leak, i) => (
              <div
                key={i}
                className={cn(
                  'glass-card rounded-2xl p-6 border-2 cursor-pointer transition-all duration-500',
                  borderColors[leak.color],
                  activeCard === i ? 'scale-[1.02]' : '',
                  isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'
                )}
                style={{ transitionDelay: `${i * 200}ms` }}
                onMouseEnter={() => setActiveCard(i)}
                onMouseLeave={() => setActiveCard(null)}
              >
                <div className="mb-4">
                  {leak.icon}
                </div>
                <h3 className="text-xl font-bold text-steel-100 mb-3">{leak.title}</h3>
                <div className="mb-4">
                  <span className={cn('text-3xl font-black', statColors[leak.color])}>{leak.stat}</span>
                  <span className="text-xs text-steel-400 block mt-1 font-mono">{leak.statLabel}</span>
                </div>
                <p className="text-sm text-steel-300 leading-relaxed">{leak.description}</p>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
